from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
from datetime import datetime, date, time
import sqlite3
import pickle
import numpy as np
import cv2
import face_recognition
import shutil

BASE = Path(__file__).resolve().parent
DB = BASE / "attendance.db"
FACES = BASE / "faces"
FACES.mkdir(exist_ok=True)

app = FastAPI(title="AI Attendance Monitoring System", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For local development. Restrict this in production.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            roll TEXT NOT NULL UNIQUE,
            class_name TEXT NOT NULL,
            image_path TEXT NOT NULL,
            encoding BLOB NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            attendance_date TEXT NOT NULL,
            attendance_time TEXT NOT NULL,
            confidence REAL NOT NULL,
            status TEXT NOT NULL,
            UNIQUE(student_id, attendance_date),
            FOREIGN KEY(student_id) REFERENCES students(id)
        )
    """)
    conn.commit()
    conn.close()

init_db()

def read_image(data: bytes):
    arr = np.frombuffer(data, dtype=np.uint8)
    image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if image is None:
        raise HTTPException(400, "Invalid image")
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

def get_encodings(rgb):
    # HOG is CPU-friendly and suitable for a local classroom prototype.
    locations = face_recognition.face_locations(rgb, model="hog")
    encodings = face_recognition.face_encodings(rgb, locations)
    return locations, encodings

def load_students():
    conn = db()
    rows = conn.execute("SELECT * FROM students").fetchall()
    conn.close()
    return rows

def attendance_today():
    today = date.today().isoformat()
    conn = db()
    rows = conn.execute("""
        SELECT a.*, s.name, s.roll, s.class_name
        FROM attendance a
        JOIN students s ON s.id = a.student_id
        WHERE a.attendance_date = ?
        ORDER BY a.attendance_time DESC
    """, (today,)).fetchall()
    conn.close()
    return rows

def verify_class_time(start: str, end: str):
    try:
        now = datetime.now().time()
        st = time.fromisoformat(start)
        en = time.fromisoformat(end)
        return st <= now <= en
    except Exception:
        return True

@app.get("/api/health")
def health():
    return {"status": "online"}

@app.get("/api/students")
def students():
    rows = load_students()
    return [{
        "id": r["id"],
        "name": r["name"],
        "roll": r["roll"],
        "class": r["class_name"],
        "status": "Authorized"
    } for r in rows]

@app.post("/api/students")
async def register_student(
    name: str = Form(...),
    roll: str = Form(...),
    class_name: str = Form(...),
    face_image: UploadFile = File(...)
):
    name, roll, class_name = name.strip(), roll.strip(), class_name.strip()
    if not name or not roll or not class_name:
        raise HTTPException(400, "All student fields are required")

    image_bytes = await face_image.read()
    rgb = read_image(image_bytes)
    locations, encodings = get_encodings(rgb)

    if len(encodings) != 1:
        raise HTTPException(
            400,
            f"Registration image must contain exactly one clear face. Detected {len(encodings)}."
        )

    conn = db()
    try:
        existing = conn.execute("SELECT id FROM students WHERE roll=?", (roll,)).fetchone()
        if existing:
            raise HTTPException(409, "Roll number already registered")

        ext = Path(face_image.filename or ".jpg").suffix.lower()
        if ext not in {".jpg", ".jpeg", ".png"}:
            ext = ".jpg"

        path = FACES / f"{roll}{ext}"
        path.write_bytes(image_bytes)

        blob = pickle.dumps(encodings[0])
        cur = conn.execute("""
            INSERT INTO students(name, roll, class_name, image_path, encoding, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (name, roll, class_name, str(path), blob, datetime.now().isoformat()))
        conn.commit()
        return {"message": "Student registered", "id": cur.lastrowid}
    finally:
        conn.close()

class RecognitionSettings(BaseModel):
    confidence_threshold: float = 75.0
    class_start: str = "09:00"
    class_end: str = "17:00"

@app.post("/api/recognize")
async def recognize(
    frame: UploadFile = File(...),
    confidence_threshold: float = Form(75.0),
    class_start: str = Form("09:00"),
    class_end: str = Form("17:00"),
):
    if not verify_class_time(class_start, class_end):
        return {
            "recognized": [],
            "message": "Attendance window is currently closed."
        }

    rgb = read_image(await frame.read())
    locations, unknown_encodings = get_encodings(rgb)
    students = load_students()

    known_encodings = []
    known_rows = []
    for s in students:
        try:
            enc = pickle.loads(s["encoding"])
            known_encodings.append(enc)
            known_rows.append(s)
        except Exception:
            continue

    results = []
    today = date.today().isoformat()
    now = datetime.now().strftime("%H:%M:%S")

    for enc in unknown_encodings:
        if not known_encodings:
            continue

        distances = face_recognition.face_distance(known_encodings, enc)
        idx = int(np.argmin(distances))
        distance = float(distances[idx])

        # Convert distance to an approximate 0-100 similarity score.
        confidence = max(0.0, min(100.0, (1.0 - distance) * 100.0))
        student = known_rows[idx]

        # Recognition threshold: lower distance is better.
        if distance > 0.55 or confidence < confidence_threshold:
            continue

        conn = db()
        existing = conn.execute("""
            SELECT id FROM attendance
            WHERE student_id=? AND attendance_date=?
        """, (student["id"], today)).fetchone()

        duplicate = existing is not None
        if not duplicate:
            conn.execute("""
                INSERT INTO attendance(
                    student_id, attendance_date, attendance_time, confidence, status
                ) VALUES (?, ?, ?, ?, ?)
            """, (student["id"], today, now, confidence, "Present"))
            conn.commit()
        conn.close()

        results.append({
            "name": student["name"],
            "roll": student["roll"],
            "class": student["class_name"],
            "confidence": round(confidence, 1),
            "status": "Already marked" if duplicate else "Present"
        })

    return {
        "faces_detected": len(unknown_encodings),
        "recognized": results,
        "message": "Recognition complete"
    }

@app.get("/api/attendance")
def get_attendance():
    rows = attendance_today()
    return [{
        "date": r["attendance_date"],
        "name": r["name"],
        "roll": r["roll"],
        "time": r["attendance_time"],
        "confidence": round(r["confidence"], 1),
        "status": r["status"]
    } for r in rows]

@app.delete("/api/attendance")
def clear_attendance():
    conn = db()
    conn.execute("DELETE FROM attendance")
    conn.commit()
    conn.close()
    return {"message": "Attendance cleared"}

@app.get("/api/dashboard")
def dashboard():
    students_count = len(load_students())
    rows = attendance_today()
    present = len(rows)
    absent = max(0, students_count - present)
    rate = round((present / students_count) * 100) if students_count else 0
    return {
        "totalStudents": students_count,
        "presentStudents": present,
        "absentStudents": absent,
        "attendanceRate": rate,
        "records": [{
            "date": r["attendance_date"],
            "name": r["name"],
            "roll": r["roll"],
            "time": r["attendance_time"],
            "confidence": round(r["confidence"], 1),
            "status": r["status"]
        } for r in rows]
    }

app.mount("/", StaticFiles(directory=BASE.parent / "frontend", html=True), name="frontend")

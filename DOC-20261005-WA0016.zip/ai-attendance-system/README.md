# AI-Enabled Attendance Monitoring System

## What this project does

- FastAPI backend
- SQLite database
- OpenCV image decoding
- `face_recognition` face detection/encoding
- Authorized student registration
- Face matching
- Configurable confidence threshold
- Class start/end time validation
- One attendance record per student per day
- Dashboard statistics
- Attendance history
- CSV export
- Browser camera access

## 1. Create a virtual environment

### Windows

```bash
cd ai-attendance-system
py -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
cd ai-attendance-system
python3 -m venv .venv
source .venv/bin/activate
```

## 2. Install dependencies

```bash
pip install --upgrade pip
pip install -r backend/requirements.txt
```

`face-recognition` depends on native packages. If installation fails on your machine, install the prerequisites for your OS first, then rerun the requirements command.

## 3. Start the server

```bash
cd backend
uvicorn main:app --reload
```

Open:

http://127.0.0.1:8000

Do NOT open `frontend/index.html` directly. The FastAPI server serves the frontend and API together.

## 4. Register students

Open Students.

For each student:

1. Enter name.
2. Enter roll number.
3. Enter class.
4. Upload a clear photo containing exactly one face.
5. Click Register Student.

Use a front-facing, well-lit image for best results.

## 5. Mark attendance

1. Open AI Camera.
2. Click Start Camera.
3. Allow browser camera permission.
4. Make sure the registered student is visible.
5. Click Recognize & Mark.

The backend will:

1. Receive the camera frame.
2. Detect faces.
3. Generate face encodings.
4. Compare them with authorized profiles.
5. Apply the confidence threshold.
6. Check class timing.
7. Prevent duplicate attendance for the same day.
8. Save a record to SQLite.

## API endpoints

- GET `/api/health`
- GET `/api/students`
- POST `/api/students`
- POST `/api/recognize`
- GET `/api/attendance`
- DELETE `/api/attendance`
- GET `/api/dashboard`

## Important production notes

This is an educational/local prototype, not a production biometric system.

Before using it in a real school/college:

- Obtain appropriate consent and follow applicable privacy/data-protection requirements.
- Protect biometric data at rest and in transit.
- Add authentication and role-based access.
- Use HTTPS.
- Restrict CORS to the actual frontend domain.
- Add liveness/anti-spoofing.
- Do not rely on face recognition alone for disciplinary decisions.
- Test accuracy across lighting, pose, camera quality, and demographic groups.
- Add an explicit manual correction/audit workflow.
- Use PostgreSQL or another managed database for multi-user deployments.
